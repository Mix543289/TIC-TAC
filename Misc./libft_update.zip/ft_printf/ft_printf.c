/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/08 18:55:31 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/08 18:55:31 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_printf(const char *input_str, ...)
{
	va_list	args;
	int		i;
	int		total_count;

	if (!input_str)
		return (-1);
	va_start(args, input_str);
	i = 0;
	total_count = 0;
	while (input_str[i])
	{
		if (input_str[i] == '%')
		{
			i++;
			total_count = total_count + ft_dispatcher(input_str[i], args);
		}
		else
		{
			write(1, &input_str[i], 1);
			total_count++;
		}
		i++;
	}
	va_end(args);
	return (total_count);
}

// int	main(void)
// {
// 	int	i;
// 	int	j;

// 	printf("Specifier [c] Tests:\n");
// 	i = printf("[OG printf] return result: %c\n", 'A');
// 	j = ft_printf("[ft_printf] return result: %c\n", 'A');
// 	ft_printf("Return for printf = %i, Return for ft_printf = %i\n", i, j);

// 	printf("Specifier [s] Tests:\n");
// 	i = printf("[OG printf] return result: %s\n", "test");
// 	j = ft_printf("[ft_printf] return result: %s\n", "test");
// 	ft_printf("Return for printf = %i, Return for ft_printf = %i\n", i, j);

// 	printf("Specifier [d] Tests:\n");
// 	i = printf("[OG printf] return result: %d\n", 11);
// 	j = ft_printf("[ft_printf] return result: %d\n", 11);
// 	ft_printf("Return for printf = %i, Return for ft_printf = %i\n", i, j);

// 	printf("Specifier [i] Tests:\n");
// 	i = printf("[OG printf] return result: %i\n", -10);
// 	j = ft_printf("[ft_printf] return result: %i\n", -10);
// 	ft_printf("Return for printf = %i, Return for ft_printf = %i\n", i, j);

// 	printf("Specifier [u] Tests:\n");
// 	i = printf("[OG printf] return result: %u\n", 12);
// 	j = ft_printf("[ft_printf] return result: %u\n", 12);
// 	ft_printf("Return for printf = %i, Return for ft_printf = %i\n", i, j);

// 	printf("Specifier [x] Tests:\n");
// 	i = printf("[OG printf] return result: %x\n", 255);
// 	j = ft_printf("[ft_printf] return result: %x\n", 255);
// 	ft_printf("Return for printf = %i, Return for ft_printf = %i\n", i, j);

// 	printf("Specifier [X] Tests:\n");
// 	i = printf("[OG printf] return result: %X\n", 127);
// 	j = ft_printf("[ft_printf] return result: %X\n", 127);
// 	ft_printf("Return for printf = %i, Return for ft_printf = %i\n", i, j);

// 	printf("Specifier [p] Tests:\n");
// 	i = printf("[OG printf] return result: %p\n", &i);
// 	j = ft_printf("[ft_printf] return result: %p\n", &i);
// 	ft_printf("Return for printf = %i, Return for ft_printf = %i\n", i, j);
// }
