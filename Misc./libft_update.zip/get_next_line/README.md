*This project has been created as part of the 42 curriculum by dcharbon.*

# get_next_line

## Description

**get_next_line** is a C function developed for the 42 Common Core. It reads a file descriptor line by line, returning one line per function call. Its purpose is to develop a deeper understanding of file descriptors, the `read()` system call, static variables, dynamic memory allocation, and memory management.

The function reads from a file descriptor using a configurable `BUFFER_SIZE`, stores unread data between calls, and returns each line including its terminating newline character (`\n`), except when the final line reaches the end of the file without one.

The project includes two implementations:

- **Mandatory part:** Handles one file descriptor at a time using a static stash.
- **Bonus part:** Handles multiple file descriptors simultaneously by maintaining a separate stash for each descriptor.

Both implementations use their own utility files and headers.

## Function reference

### Main functions

| Function | Purpose |
| --- | --- |
| `get_next_line` | Reads and returns the next line from a file descriptor. Returns `NULL` when there is nothing left to read or when an error occurs. |
| `read_and_grab` | Allocates a temporary reading buffer and reads up to `BUFFER_SIZE` bytes from the file descriptor. |
| `update_stash` | Reads additional data and appends it to the stash until a newline is found or the end of the file is reached. |
| `extract_and_update_stash` | Extracts the next line from the stash and preserves the remaining characters for the next call. |

### Utility functions

| Function | Purpose |
| --- | --- |
| `ft_strlen` | Calculates the length of a string. |
| `ft_strjoin` | Concatenates two strings into a newly allocated string. |
| `ft_calloc` | Allocates memory and initializes it to zero. |
| `ft_strdup` | Creates a dynamically allocated duplicate of a string. |
| `ft_strchr` | Searches for a specific character in a string. |
| `ft_substr` | Creates a substring from a given string, starting at a specified index. |

### Mandatory and bonus implementations

| Feature | Mandatory | Bonus |
| --- | --- | --- |
| File descriptors | One at a time | Multiple simultaneously |
| Static storage | One static stash | Static array of stashes |
| Newline detection | Supported | Supported |
| End-of-file handling | Supported | Supported |
| Configurable `BUFFER_SIZE` | Supported | Supported |
| Independent data storage per FD | Not required | Supported |

The bonus implementation uses a static stash array indexed by the file descriptor. The current implementation defines a limit of 1024 entries.

## Instructions

### Requirements

- A C compiler (`cc`)
- Standard C library
- POSIX-compatible system calls, including `read()`, `close()`, and `open()`
- `make` is optional; compilation can be performed directly with `cc`

### Compilation

From the `get_next_line` directory, compile the mandatory implementation with:

```sh
cc -Wall -Wextra -Werror -D BUFFER_SIZE=42 \
main.c get_next_line.c get_next_line_utils.c -o gnl
```

Compile the bonus implementation separately:

```sh
cc -Wall -Wextra -Werror -D BUFFER_SIZE=42 \
main.c get_next_line_bonus.c get_next_line_utils_bonus.c -o gnl_bonus
```

The mandatory and bonus implementations must be compiled separately because they define functions with identical names.

The `BUFFER_SIZE` value can be changed at compilation time. If it is not explicitly defined, the headers provide a default value of `3`.

### Usage

Include the appropriate header in your C program.

For the mandatory implementation:

```c
#include "get_next_line.h"
```

For the bonus implementation:

```c
#include "get_next_line_bonus.h"
```

Example usage:

```c
#include "get_next_line.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

int	main(void)
{
	int		fd;
	char	*line;

	fd = open("test.txt", O_RDONLY);
	if (fd < 0)
		return (1);
	line = get_next_line(fd);
	while (line != NULL)
	{
		printf("%s", line);
		free(line);
		line = get_next_line(fd);
	}
	close(fd);
	return (0);
}
```

Each returned line is dynamically allocated and must be freed by the caller.

### Bonus usage

The bonus implementation allows calls to `get_next_line()` to alternate between different file descriptors while preserving their respective unread data.

For example:

```c
line_a = get_next_line(fd_a);
line_b = get_next_line(fd_b);
line_a = get_next_line(fd_a);
line_b = get_next_line(fd_b);
```

Each file descriptor maintains its own stash, allowing independent reading progress.

## Verification

Before submitting, verify that:

- All mandatory and bonus source files compile independently.
- Compilation succeeds with `-Wall -Wextra -Werror`.
- Different `BUFFER_SIZE` values work correctly.
- Empty files return `NULL`.
- Lines ending with `\n` are returned correctly.
- The final line is returned even when it has no terminating newline.
- Multiple consecutive calls preserve unread data.
- The bonus implementation correctly handles multiple file descriptors.
- Invalid file descriptors and read errors are handled.
- Every returned line is properly freed by the caller.
- The Norminette is run on all C source files and headers.

Pay particular attention to memory allocation failures, file descriptor handling, newline boundaries, and end-of-file behavior.

## Resources

### References

- **Get Next Line subject** — the official project specifications and requirements, available through [42 Intra](https://intra.42.fr/).
- [Linux manual pages](https://man7.org/linux/man-pages/) — documentation for `read()`, `open()`, `close()`, and file descriptor behavior.
- [cppreference — C](https://en.cppreference.com/w/c) — C language reference, including pointers, memory allocation, and standard library functions.
- [42 Norminette](https://github.com/42School/norminette) — the coding style enforced by 42.
- [42 GitHub](https://github.com/42School) — official 42 resources and tools.

### AI tools and learning approach

**OpenAI ChatGPT — GPT-6** was used as a learning and development support tool during this project.

AI assistance included:

- Explanations of file descriptors, static variables, and buffer management.
- Code review and debugging guidance.
- Analysis of memory allocation and deallocation.
- Discussion of edge cases and error handling.
- Assistance with testing strategies and project documentation.

AI assistance was used as a learning resource rather than a substitute for understanding the implementation. Particular attention was given to understanding pointer ownership, memory allocation, stash management, and the differences between the mandatory and bonus implementations.

This README was prepared with AI writing assistance and reviewed against the project's implementation.

## Notes

This implementation is designed around the requirements of the 42 Get Next Line project. It focuses on returning one line per call, preserving unread data between calls, and managing dynamically allocated memory.

The mandatory implementation maintains a single static stash, while the bonus implementation uses a static array to maintain separate stashes for multiple file descriptors.

The current bonus implementation limits accepted file descriptors to values below 1024. This is an implementation constraint rather than an unrestricted file descriptor management system.

The project does not include a separate Makefile in the current directory. The source files can be compiled directly using the commands provided above.

The submitted source files must satisfy the project's compilation, memory management, Norminette, and functional requirements.