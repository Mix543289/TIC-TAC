*This project has been created as part of the 42 curriculum by dcharbon.*

# Libft

## Description

**Libft** is a static C library developed for the 42 Common Core. It recreates standard library functions and adds utilities for working with strings, file descriptors, and singly linked lists. Its purpose is to build a foundation in C programming, pointers, memory allocation, defensive error handling, and modular code.

The project contains **43 functions across three mandatory parts**, as specified in the Libft subject, version 19.2. The library is compiled into `libft.a`, with public declarations in `libft.h`.

## Function reference

### Part 1 — Libc functions (23 functions)

| Function | Purpose |
| --- | --- |
| `ft_isalpha` | Check whether a character is alphabetic. |
| `ft_isdigit` | Check whether a character is a decimal digit. |
| `ft_isalnum` | Check whether a character is alphanumeric. |
| `ft_isascii` | Check whether a value belongs to the ASCII character set. |
| `ft_isprint` | Check whether a character is printable. |
| `ft_strlen` | Return the length of a string, excluding its null terminator. |
| `ft_memset` | Fill a memory area with a specified byte. |
| `ft_bzero` | Set a memory area to zero. |
| `ft_memcpy` | Copy a number of bytes between non-overlapping memory areas. |
| `ft_memmove` | Copy bytes safely even when source and destination overlap. |
| `ft_strlcpy` | Copy a string into a size-limited buffer, with null termination when size permits. |
| `ft_strlcat` | Append a string to a size-limited destination buffer. |
| `ft_toupper` | Convert a lowercase letter to uppercase. |
| `ft_tolower` | Convert an uppercase letter to lowercase. |
| `ft_strchr` | Find the first occurrence of a character in a string. |
| `ft_strrchr` | Find the last occurrence of a character in a string. |
| `ft_strncmp` | Compare two strings up to a specified number of bytes. |
| `ft_memchr` | Search for a byte in a memory area. |
| `ft_memcmp` | Compare two memory areas byte by byte. |
| `ft_strnstr` | Find a substring within a size-limited part of another string. |
| `ft_atoi` | Convert the beginning of a string into an integer. |
| `ft_calloc` | Allocate a zero-initialized memory block. |
| `ft_strdup` | Allocate and return a duplicate of a string. |

### Part 2 — Additional functions (11 functions)

| Function | Purpose |
| --- | --- |
| `ft_substr` | Allocate a substring starting at a given index, with a maximum length. |
| `ft_strjoin` | Allocate a new string by concatenating two strings. |
| `ft_strtrim` | Remove specified characters from both ends of a string, returning a new string. |
| `ft_split` | Split a string on a delimiter into a newly allocated, NULL-terminated array of strings. |
| `ft_itoa` | Convert an integer into a newly allocated string. |
| `ft_strmapi` | Apply a function to each character and index, producing a new string. |
| `ft_striteri` | Apply a function to each character by address, allowing in-place modification. |
| `ft_putchar_fd` | Write one character to a file descriptor. |
| `ft_putstr_fd` | Write a string to a file descriptor. |
| `ft_putendl_fd` | Write a string followed by a newline to a file descriptor. |
| `ft_putnbr_fd` | Write an integer in decimal form to a file descriptor. |

### Part 3 — Linked lists (9 functions)

The library defines `t_list` in `libft.h`. Each node contains a `void *content` pointer and a `next` pointer to the following node.

| Function | Purpose |
| --- | --- |
| `ft_lstnew` | Allocate a new node containing the supplied content. |
| `ft_lstadd_front` | Insert a node at the beginning of a list. |
| `ft_lstsize` | Count the nodes in a list. |
| `ft_lstlast` | Return the last node in a list. |
| `ft_lstadd_back` | Append a node to the end of a list. |
| `ft_lstdelone` | Delete one node and its content using a supplied deletion function. |
| `ft_lstclear` | Delete a node and all following nodes, setting the list pointer to NULL. |
| `ft_lstiter` | Apply a function to the content of every node. |
| `ft_lstmap` | Build a new list by applying a function to each source node's content, with cleanup on allocation failure. |

## Instructions

### Requirements

- A C compiler (`cc`)
- `make`
- `ar` for creating the static library

### Compilation

From the directory containing the Libft Makefile, run:

```sh
make
```

The Makefile should create `libft.a` and provide the required rules:

```sh
make          # Build libft.a
make all      # Build libft.a
make clean    # Remove object files
make fclean   # Remove object files and libft.a
make re       # Rebuild the library
```

To use Libft in another C program, include the header:

```c
#include "libft.h"
```

Then compile and link against the library, for example from the Libft directory:

```sh
cc -Wall -Wextra -Werror -I. main.c -L. -lft -o program
```

### Verification

Before submitting, check that all 43 function sources are included in the Makefile, run the Norminette on C sources and headers, and test compilation, behavior, and memory handling. The `libft.a` archive can be inspected with:

```sh
ar t libft.a
```

## Resources

### References

- **Libft subject, version 19.2** — the project specifications and function prototypes, available through [42 Intra](https://intra.42.fr/).
- [Linux manual pages](https://man7.org/linux/man-pages/) — standard library and system-call behavior, including `malloc`, `free`, and `write`.
- [cppreference — C](https://en.cppreference.com/w/c) — C syntax, pointers, types, and memory concepts.
- [42 Norminette](https://github.com/42School/norminette) — the coding style enforced by 42.

### AI tools and learning approach

AI tools used or consulted during the student's learning and development workflow include:

- **OpenAI ChatGPT — GPT-6:** explanations of C concepts, discussion of algorithms, iterative code review, debugging guidance, and assistance with test analysis and project documentation.
- **Google Gemini 3.1 Pro** and **Qwen 3.8:** additional AI models consulted as part of the student's development and learning environment.
- **Sidekick-AI:** a separate, student-built AI assistant project intended to support technical research, development workflows, and learning. It is referenced here as part of the student's broader tooling, **not** as a component of the submitted Libft library.

AI assistance was used as a learning and review resource, not as a substitute for understanding the implementation. Functions were written and revised iteratively, with attention to being able to explain their logic, memory management, and edge cases. This README was prepared with AI writing assistance and reviewed for the project's requirements.

## Notes

All three parts, including the linked-list functions, are mandatory in the version 19.2 subject. The submitted code and `libft.a` must satisfy the project's compilation, style, and memory-management requirements.
