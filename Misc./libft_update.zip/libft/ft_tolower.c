/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/20 11:25:49 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/03 20:31:48 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_tolower(int c)
{
	if (c >= 65 && c <= 90)
		return (c + 32);
	return (c);
}

// int	main(void)
// {
// 	char	l;
// 	char	m;

// 	l = 'Z';
// 	m = ft_tolower(l);
// 	printf("Original: %c -> Minuscule: %c \n", l, m);
// 	return (0);
// }