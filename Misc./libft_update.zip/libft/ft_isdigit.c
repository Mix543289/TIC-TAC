/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/19 19:41:30 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/03 22:07:44 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isdigit(int c)
{
	if (c >= '0' && c <= '9')
		return (1);
	return (0);
}

// int	main(void)
// {
// 	char	l;
// 	int		t;

// 	l = 'Z';
// 	t = ft_isdigit(l);
// 	if (t == 1)
// 	{
// 		printf("[%c] est un 'digit'. \n", l);
// 	}
// 	else
// 	{
// 		printf("[%c] n'est pas un 'digit'. \n", l);
// 	}
// 	return (0);
// }
