/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/19 19:40:29 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/03 22:18:20 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isalnum(int c)
{
	if ((c >= 'A' && c <= 'Z')
		|| (c >= 'a' && c <= 'z')
		|| (c >= '0' && c <= '9'))
		return (1);
	return (0);
}

// int	main(void)
// {
// 	char	l;
// 	int		t;

// 	l = 'Z';
// 	t = ft_isalnum(l);
// 	if (t == 1)
// 	{
// 		printf("[%c] est un caractere alphanumerique. \n", l);
// 	}
// 	else
// 	{
// 		printf("[%c] n'est pas un caractere alphanumerique. \n", l);
// 	}
// 	return (0);
// }
