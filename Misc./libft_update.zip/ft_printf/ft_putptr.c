/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putptr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/08 20:18:14 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/09 11:05:38 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putptr(void *ptr)
{
	int	count;

	count = 0;
	if (ptr == NULL)
		count = count + ft_putstr("(nil)");
	else
	{
		count = count + ft_putstr("0x");
		count = count + ft_puthex((unsigned long)ptr, 'x');
	}
	return (count);
}
