/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/20 11:32:58 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/03 20:17:54 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_toupper(int c)
{
	if (c >= 97 && c <= 122)
		return (c - 32);
	return (c);
}

// int	main(void)

// {
// 	char	l;
// 	char	m;

// 	l = 'a';
// 	m = ft_toupper(l);
// 	printf("Original : %c -> Majuscule : %c\n", l, m);
// 	return (0);
// }
