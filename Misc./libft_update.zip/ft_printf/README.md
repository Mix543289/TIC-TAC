*This project has been created as part of the 42 curriculum by dcharbon.*

# ft_printf

## Description

**ft_printf** is a static C library developed for the 42 Common Core. It recreates a limited version of the standard `printf` function, writing formatted output to standard output and returning the number of characters printed. Its purpose is to develop an understanding of variadic functions, format specifiers, numeric conversions, recursion, and modular code.

The project supports **nine conversion specifiers**: `%c`, `%s`, `%p`, `%d`, `%i`, `%u`, `%x`, `%X`, and `%%`. The library is compiled into `libftprintf.a`, with public declarations in `ft_printf.h`.

## Function reference

### Supported conversions

| Specifier | Purpose |
| --- | --- |
| `%c` | Print a single character. |
| `%s` | Print a string. |
| `%p` | Print a pointer address in hexadecimal notation. |
| `%d` | Print a signed decimal integer. |
| `%i` | Print a signed decimal integer. |
| `%u` | Print an unsigned decimal integer. |
| `%x` | Print an unsigned integer in lowercase hexadecimal. |
| `%X` | Print an unsigned integer in uppercase hexadecimal. |
| `%%` | Print a literal percent sign. |

### Implementation functions

| Function | Purpose |
| --- | --- |
| `ft_printf` | Parse the input string, dispatch conversions, and return the total number of characters printed. |
| `ft_dispatcher` | Select the appropriate output function based on a conversion specifier and retrieve its variadic argument. |
| `ft_putchar` | Write one character and return the number of characters printed. |
| `ft_putstr` | Write a string and return the number of characters printed. |
| `ft_putnbr` | Print a signed integer in decimal notation. |
| `ft_putunbr` | Print an unsigned integer in decimal notation. |
| `ft_puthex` | Print a number in hexadecimal notation using lowercase or uppercase digits. |
| `ft_putptr` | Print a pointer address, including handling a null pointer. |

## Instructions

### Requirements

- A C compiler (`cc`)
- `make`
- `ar` for creating the static library

### Compilation

From the directory containing the ft_printf Makefile, run:

```sh
make
```

The Makefile creates `libftprintf.a` and provides the required rules:

```sh
make          # Build libftprintf.a
make all      # Build libftprintf.a
make clean    # Remove object files
make fclean   # Remove object files and libftprintf.a
make re       # Rebuild the library
```

To use ft_printf in another C program, include the header:

```c
#include "ft_printf.h"
```

Then compile and link against the library, for example from the ft_printf directory:

```sh
cc -Wall -Wextra -Werror -I. main.c -L. -lftprintf -o program
```

Example usage:

```c
ft_printf("Hello %s, value: %d, hex: %x\n", "42", 255, 255);
```

### Verification

Before submitting, check that all source files are included in the Makefile, run the Norminette on C sources and headers, and verify compilation, output, and return values against the standard `printf` function. Pay particular attention to numeric limits, null pointers, null characters, and mixed conversions.

The library archive can be inspected with:

```sh
ar t libftprintf.a
```

The mandatory conversion tests from [Tripouille's printfTester](https://github.com/Tripouille/printfTester) were also used during development. Passing a tester does not replace checking the current project subject, the Norminette, and the final submitted build.

## Resources

### References

- **ft_printf subject** — the project specifications and required conversions, available through [42 Intra](https://intra.42.fr/).
- [Linux manual pages](https://man7.org/linux/man-pages/) — standard library and system-call behavior, including `printf` and `write`.
- [cppreference — C](https://en.cppreference.com/w/c) — variadic functions, integer types, conversions, and C syntax.
- [42 Norminette](https://github.com/42School/norminette) — the coding style enforced by 42.
- [Tripouille/printfTester](https://github.com/Tripouille/printfTester) — functional tests for the ft_printf project.

### AI tools and learning approach

AI tools used or consulted during the student's learning and development workflow include:

- **OpenAI ChatGPT — GPT-6:** explanations of variadic arguments and format conversions, iterative code review, debugging guidance, test analysis, and assistance with project documentation.
- **Google Gemini 3.1 Pro** and **Qwen 3.8:** additional AI models consulted as part of the student's development and learning environment.
- **Sidekick-AI:** a separate, student-built AI assistant project intended to support technical research, development workflows, and learning. It is referenced here as part of the student's broader tooling, **not** as a component of the submitted ft_printf library.

AI assistance was used as a learning and review resource, not as a substitute for understanding the implementation. Functions were written and revised iteratively, with attention to being able to explain variadic argument handling, conversion logic, and edge cases. This README was prepared with AI writing assistance and reviewed for the project's requirements.

## Notes

This implementation covers the required conversion specifiers listed above; it does not attempt to reproduce the full standard `printf` formatting feature set, such as field width, precision, or flags. The submitted code and `libftprintf.a` must satisfy the project's compilation, style, and functional requirements.
