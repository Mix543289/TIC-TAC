/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/19 19:38:37 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/03 22:17:17 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isprint(int c)
{
	if (c >= 32 && c <= 126)
		return (1);
	return (0);
}

// int	main(void)
// {
// 	char	l;
// 	int		t;

// 	l = 'Z';
// 	t = ft_isprint(l);
// 	if (t == 1)
// 	{
// 		printf("[%c] est 'printable'. \n", l);
// 	}
// 	else
// 	{
// 		printf("[%c] n'est pas 'printable'. \n", l);
// 	}
// 	return (0);
// }
