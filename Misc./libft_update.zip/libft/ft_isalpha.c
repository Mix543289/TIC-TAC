/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalpha.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/19 18:58:43 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/03 22:00:27 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isalpha(int c)
{
	if ((c >= 'A' && c <= 'Z')
		|| (c >= 'a' && c <= 'z'))
		return (1);
	return (0);
}
// int	main(void)
// {
// 	char	l;
// 	int		t;

// 	l = 'Z';
// 	t = ft_isalpha(l);
// 	if (t == 1)
// 	{
// 		printf("[%c] est un caractere alphabetique. \n", l);
// 	}
// 	else
// 	{
// 		printf("[%c] n'est pas un caractere alphabetique. \n", l);
// 	}
// 	return (0);
// }
