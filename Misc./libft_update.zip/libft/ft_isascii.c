/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isascii.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcharbon <dcharbon@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/19 19:39:39 by dcharbon          #+#    #+#             */
/*   Updated: 2026/11/03 22:05:00 by dcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isascii(int c)
{
	if (c >= 0 && c <= 127)
		return (1);
	return (0);
}

// int	main(void)
// {
// 	char	l;
// 	int		t;

// 	l = 'Z';
// 	t = ft_isascii(l);
// 	if (t == 1)
// 	{
// 		printf("[%c] est dans la table ASCII 'standard'. \n", l);
// 	}
// 	else
// 	{
// 		printf("[%c] n'est pas dans la table ASCII 'standard'. \n", l);
// 	}
// 	return (0);
// }
